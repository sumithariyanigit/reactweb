import React from "react" ;


function Counter() {
    return (
     <>

   <section className="counter">
            <div className="container">
               <div className="row">
                   <div className="col-lg-4">
                       <h2>5000+</h2>
                       <h5>Trained Professionals</h5>
                   </div>
                   <div className="col-lg-4">
                       <h2>2 Million+</h2>
                       <h5>Happy Customers</h5>
                   </div>
                   <div className="col-lg-4">
                       <h2>42</h2>
                       <h5>Citites</h5>
                   </div>
                </div>
            </div>
    </section>

     </>
);
}

export default Counter;