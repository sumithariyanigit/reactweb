import React from "react" ;




function HeroBanner() {
    return (
 <>

<section className="hero__area hero__height p-relative d-flex align-items-center"> 
  
   <div className="container">
      <div className="row align-items-center">
         <div className="col-lg-12 mt-70">
            <div className="hero__content pr-80 text-center">
             {/* <h1>Test</h1> */}
            </div>
         </div>
         
      </div>
   </div>
</section>
  
      </>
    );
  }

export default HeroBanner