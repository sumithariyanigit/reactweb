import React from "react";

function ReviewUser() {
return (
<>
  <div className="review-style wow fadeInRight" data-wow-delay=".1s">
    <div className="row">
      <div className="col-lg-12">
        <div className="review-list">
          <div className="userImg">
            <img src={process.env.PUBLIC_URL + '/assets/images/user.png'} />
          </div>
          <div>
            <div className="reviewUser">
              <h3>John Pauls</h3>
              <div className="rating">
                <ul>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className=""><i className="icon_star"></i></li>
                </ul>
              </div>
            </div>
            <div className="commment">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                when an unknown printer took a galley of type It has survived not only five centuries,
                but also the leap into Contrary to popular belief, Lorem Ipsum is not simply
              </p>
              <div className='certified'>
                <i className="fad fa-badge-check"></i> certified user
              </div>

            </div>
          </div>

        </div>
        <div className="review-list">
          <div className="userImg">
            <img src={process.env.PUBLIC_URL + '/assets/images/user.png'} />
          </div>
          <div>
            <div className="reviewUser">
              <h3>John Pauls</h3>
              <div className="rating">
                <ul>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className=""><i className="icon_star"></i></li>
                </ul>
              </div>
            </div>
            <div className="commment">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                when an unknown printer took a galley of type It has survived not only five centuries,
                but also the leap into Contrary to popular belief, Lorem Ipsum is not simply
              </p>
              <div className='certified'>
                <i className="fad fa-badge-check"></i> certified user
              </div>
            </div>

          </div>

        </div>
        <div className="review-list">
          <div className="userImg">
            <img src={process.env.PUBLIC_URL + '/assets/images/user.png'} />
          </div>
          <div>
            <div className="reviewUser">
              <h3>John Pauls</h3>
              <div className="rating">
                <ul>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className=""><i className="icon_star"></i></li>
                </ul>
              </div>
            </div>
            <div className="commment">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                when an unknown printer took a galley of type It has survived not only five centuries,
                but also the leap into Contrary to popular belief, Lorem Ipsum is not simply
              </p>
              <div className='certified'>
                <i className="fad fa-badge-check"></i> certified user
              </div>
            </div>

          </div>

        </div>
        <div className="review-list">
          <div className="userImg">
            <img src={process.env.PUBLIC_URL + '/assets/images/user.png'} />
          </div>
          <div>
            <div className="reviewUser">
              <h3>John Pauls</h3>
              <div className="rating">
                <ul>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className=""><i className="icon_star"></i></li>
                </ul>
              </div>
            </div>
            <div className="commment">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                when an unknown printer took a galley of type It has survived not only five centuries,
                but also the leap into Contrary to popular belief, Lorem Ipsum is not simply
              </p>
              <div className='certified'>
                <i className="fad fa-badge-check"></i> certified user
              </div>
            </div>

          </div>

        </div>
        <div className="review-list">
          <div className="userImg">
            <img src={process.env.PUBLIC_URL + '/assets/images/user.png'} />
          </div>
          <div>
            <div className="reviewUser">
              <h3>John Pauls</h3>
              <div className="rating">
                <ul>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className="active"><i className="icon_star"></i></li>
                  <li className=""><i className="icon_star"></i></li>
                </ul>
              </div>
            </div>
            <div className="commment">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                when an unknown printer took a galley of type It has survived not only five centuries,
                but also the leap into Contrary to popular belief, Lorem Ipsum is not simply
              </p>
              <div className='certified'>
                <i className="fad fa-badge-check"></i> certified user
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  </div>
</>
)};

export default ReviewUser;
